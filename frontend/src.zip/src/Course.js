import React, { useState } from 'react';
import './Course.css';

export default function Course() {
  const [activeTab, setActiveTab] = useState('Home');

  const renderContent = () => {
    switch (activeTab) {
      case 'Home':
        return (
          <>
            <h2>Welcome to CSIS 7077</h2>
            <ul>
              <li>Task 2</li>
              <li>Discuss both views</li>
              <li>Sample answer</li>
            </ul>
          </>
        );
      case 'Assignments':
        return (
          <>
            <h2>Assignments</h2>
            <p>📌 Assignment 1: Essay on Climate Change – Due 4/22</p>
            <p>📌 Assignment 2: Data Analysis Project – Due 4/30</p>
          </>
        );
      case 'Announcements':
        return (
          <>
            <h2>Announcements</h2>
            <p>📢 Midterm postponed to next Monday.</p>
            <p>📢 New resources uploaded in the Syllabus tab.</p>
          </>
        );
      case 'Grades':
        return (
          <>
            <h2>Your Grades</h2>
            <ul>
              <li>Assignment 1: 92%</li>
              <li>Quiz 1: 85%</li>
              <li>Project: 97%</li>
            </ul>
          </>
        );
      case 'Syllabus':
        return (
          <>
            <h2>Course Syllabus</h2>
            <p>This course covers advanced essay writing, critical thinking, and peer review techniques.</p>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <div className="course-page">
      <div className="sidebar">
        <ul>
          {['Home', 'Assignments', 'Announcements', 'Grades', 'Syllabus'].map(tab => (
            <li
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={activeTab === tab ? 'active' : ''}
            >
              {tab}
            </li>
          ))}
        </ul>
        <img src="/books.png" alt="Books" />
      </div>

      <div className="course-content">
        {renderContent()}
      </div>

      <footer>brightboard.edu</footer>
    </div>
  );
}
